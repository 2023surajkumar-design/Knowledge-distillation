#!/usr/bin/env python3
"""
scripts/ablation_kd_T_lambda.py  —  TASK 4 mandatory ablation: KD temperature T
and KD weight λ (the assignment requires an ablation on T or λ; this does both).

For each (T, λ) it trains a fresh warm-started ternary ResNet18 with vanilla KD
for a SHORT screening budget (default 40 epochs, single seed) on the training
split, records best VALIDATION accuracy, and writes:
    results/kd_ablation_T_lambda.csv
    plots/kd_ablation_T_lambda_heatmap.png

This is a controlled grid (reproducible and easy to explain — preferable to a
black-box search for the graded ablation). It uses the validation split only;
the test set is never touched. After finding the best (T, λ), run the full
200-epoch × 3-seed model with:
    uv run scripts/train_student_ternary.py --kd-mode vanilla \
        --temperature <T*> --kd-lambda <λ*> --teacher <path>

Multi-fidelity note: 40 warm-started epochs is a screening budget to RANK
configs, not to reach final accuracy. Reduce --temperatures/--lambdas or
--epochs if compute is tight (25 cells × 40 ep ≈ a few GPU-hours).
"""

from __future__ import annotations

import argparse
import csv
import os
import sys

import numpy as np
import torch
import torch.nn as nn

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

from src.data import get_train_val_loaders  # noqa: E402
from src.models.resnet_cifar import resnet18_cifar  # noqa: E402
from src.quant.ternary import (  # noqa: E402
    QuantConfig, convert_to_ternary, ternary_parameter_groups,
)
from src.training.utils import (  # noqa: E402
    set_seed, get_device, make_warmup_cosine, evaluate,
)
from src.kd.vanilla import load_teacher, train_one_epoch_kd  # noqa: E402

try:
    from tqdm.auto import tqdm
except Exception:  # pragma: no cover
    def tqdm(x=None, *a, **k):
        return x


def parse_args():
    p = argparse.ArgumentParser(description="Task 4 — KD T×λ ablation grid")
    p.add_argument("--teacher", default="results/best_models/resnet34_cifar10_fp32_final.pth")
    p.add_argument("--teacher-arch", default="resnet34")
    p.add_argument("--warm-start", default="results/best_models/resnet18_fp32_best.pth")
    p.add_argument("--temperatures", type=float, nargs="+", default=[1, 2, 4, 8, 16])
    p.add_argument("--lambdas", type=float, nargs="+", default=[0.1, 0.3, 0.5, 0.7, 0.9])
    p.add_argument("--epochs", type=int, default=40, help="screening budget per cell")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--batch-size", type=int, default=128)
    p.add_argument("--lr", type=float, default=0.1)
    p.add_argument("--weight-decay", type=float, default=1e-4)
    p.add_argument("--warmup-epochs", type=int, default=3)
    p.add_argument("--label-smoothing", type=float, default=0.1)
    p.add_argument("--num-workers", type=int, default=4)
    # quantizer (match the Task 3 baseline default)
    p.add_argument("--threshold", choices=["twn", "ttq"], default="twn")
    p.add_argument("--scale", choices=["derived", "learned"], default="derived")
    p.add_argument("--scope", choices=["per_channel", "per_tensor"], default="per_channel")
    p.add_argument("--csv", default="results/kd_ablation_T_lambda.csv")
    p.add_argument("--heatmap", default="plots/kd_ablation_T_lambda_heatmap.png")
    p.add_argument("--smoke", action="store_true", default=False)
    return p.parse_args()


def train_cell(T, lam, args, cfg, device, teacher):
    set_seed(args.seed)
    eff_lr = args.lr * args.batch_size / 128.0
    epochs = 1 if args.smoke else args.epochs
    train_loader, val_loader, _, _ = get_train_val_loaders(
        batch_size=args.batch_size, num_workers=args.num_workers, loader_seed=args.seed)

    model = resnet18_cifar(10)
    if args.warm_start and os.path.exists(args.warm_start):
        model.load_state_dict(torch.load(args.warm_start, map_location="cpu",
                                         weights_only=False)["model_state_dict"])
    convert_to_ternary(model, cfg)
    model = model.to(device)

    criterion = nn.CrossEntropyLoss(label_smoothing=args.label_smoothing)
    optimizer = torch.optim.SGD(ternary_parameter_groups(model, args.weight_decay),
                                lr=eff_lr, momentum=0.9, nesterov=True)
    scheduler = make_warmup_cosine(optimizer, args.warmup_epochs, epochs)

    best_val = 0.0
    for epoch in range(1, epochs + 1):
        train_one_epoch_kd(model, teacher, train_loader, optimizer, device, T, lam, criterion,
                           progress=lambda it: tqdm(it, desc=f"T{T:g}λ{lam:g} e{epoch}/{epochs}", leave=False))
        _, va = evaluate(model, val_loader, criterion, device)
        scheduler.step()
        best_val = max(best_val, va)
    return best_val


def main():
    args = parse_args()
    device = get_device()
    cfg = QuantConfig(threshold=args.threshold, scale=args.scale, scope=args.scope).validate()
    if not os.path.exists(args.teacher):
        raise FileNotFoundError(f"Teacher not found: {args.teacher}")
    teacher, _ = load_teacher(args.teacher, device, arch=args.teacher_arch)
    print(f"KD T×λ ablation | teacher={args.teacher} | {len(args.temperatures)}×{len(args.lambdas)} grid "
          f"| {args.epochs} screening epochs/cell")

    grid = np.zeros((len(args.temperatures), len(args.lambdas)))
    rows = []
    for i, T in enumerate(args.temperatures):
        for j, lam in enumerate(args.lambdas):
            acc = train_cell(T, lam, args, cfg, device, teacher)
            grid[i, j] = acc
            rows.append({"T": T, "lambda": lam, "best_val_acc": acc})
            print(f"  T={T:>4g}  λ={lam:<4g} -> best val {100*acc:.2f}%")

    os.makedirs(os.path.dirname(args.csv) or ".", exist_ok=True)
    with open(args.csv, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["T", "lambda", "best_val_acc"])
        w.writeheader()
        w.writerows(rows)

    # heatmap
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(1.2 * len(args.lambdas) + 2, 1.0 * len(args.temperatures) + 2))
    im = ax.imshow(100 * grid, cmap="viridis", aspect="auto")
    ax.set_xticks(range(len(args.lambdas))); ax.set_xticklabels([f"{x:g}" for x in args.lambdas])
    ax.set_yticks(range(len(args.temperatures))); ax.set_yticklabels([f"{x:g}" for x in args.temperatures])
    ax.set_xlabel("KD weight λ"); ax.set_ylabel("Temperature T")
    ax.set_title(f"Ternary ResNet18 + vanilla KD — best val acc (%)\n({args.epochs}-epoch screen, seed {args.seed})")
    for i in range(len(args.temperatures)):
        for j in range(len(args.lambdas)):
            ax.text(j, i, f"{100*grid[i,j]:.1f}", ha="center", va="center",
                    color="white" if grid[i, j] < grid.max() * 0.85 else "black", fontsize=8)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    os.makedirs(os.path.dirname(args.heatmap) or ".", exist_ok=True)
    fig.savefig(args.heatmap, dpi=120)
    plt.close(fig)

    bi, bj = np.unravel_index(int(np.argmax(grid)), grid.shape)
    print(f"\nBest cell: T={args.temperatures[bi]:g}, λ={args.lambdas[bj]:g} "
          f"-> {100*grid[bi,bj]:.2f}% (screening).")
    print(f"CSV -> {args.csv}\nHeatmap -> {args.heatmap}")
    print("Full-train the winner: scripts/train_student_ternary.py --kd-mode vanilla "
          f"--temperature {args.temperatures[bi]:g} --kd-lambda {args.lambdas[bj]:g} --teacher {args.teacher}")


if __name__ == "__main__":
    main()
