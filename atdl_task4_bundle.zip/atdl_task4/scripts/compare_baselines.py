#!/usr/bin/env python3
"""
scripts/compare_baselines.py  —  the accuracy-ladder decomposition (validation).

Reads the per-task summary JSONs and prints the controlled comparison that is the
scientific spine of the project:

    FP32 ResNet34 teacher
        └─ capacity gap ──►  FP32 ResNet18 (Task 2)
                                 └─ quantization gap ──►  ternary ResNet18 no-KD (Task 3)
                                                              └─ KD recovery ──►  ternary + vanilla KD (Task 4)

The pivotal number is the **Task 4 − Task 3** delta (does KD help or hurt the
ternary student?). It is reported here with its sign, whatever it is.

Validation-set numbers only. Final test numbers come from
scripts/evaluate.py --final-evaluation.

Usage:
    uv run scripts/compare_baselines.py \
        --fp32-student results/resnet18_fp32_summary.json \
        --ternary-nokd results/resnet18_ternary_noKD_summary.json \
        --ternary-kd    results/resnet18_ternary_vanillaKD_ls01_T4_lam0.9_summary.json \
        --teacher-acc 95.54
"""

from __future__ import annotations

import argparse
import json
import os


def load(path):
    if path and os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return None


def acc(s):
    return None if s is None else 100.0 * s.get("val_acc_mean", float("nan"))


def std(s):
    return None if s is None else 100.0 * s.get("val_acc_std", 0.0)


def main():
    p = argparse.ArgumentParser(description="Baseline ladder comparison (val)")
    p.add_argument("--fp32-student", default="results/resnet18_fp32_summary.json")
    p.add_argument("--ternary-nokd", default="results/resnet18_ternary_noKD_summary.json")
    p.add_argument("--ternary-kd", nargs="+", default=[], help="one or more Task 4 summary JSONs")
    p.add_argument("--teacher-acc", type=float, default=None, help="teacher val/test acc (%) for reference")
    p.add_argument("--out", default="results/baseline_ladder.json")
    args = p.parse_args()

    fp = load(args.fp32_student)
    tn = load(args.ternary_nokd)
    kds = [(os.path.basename(x), load(x)) for x in args.ternary_kd]

    print("\n==== Accuracy ladder (validation, mean±std) ====")
    if args.teacher_acc is not None:
        print(f"FP32 ResNet34 teacher        : {args.teacher_acc:.2f}%")
    if fp is not None:
        print(f"FP32 ResNet18 (Task 2)       : {acc(fp):.2f}% ± {std(fp):.2f}")
    if tn is not None:
        print(f"Ternary ResNet18 no-KD (T3)  : {acc(tn):.2f}% ± {std(tn):.2f}"
              f"   (sparsity {100*tn.get('sparsity_mean',0):.1f}%)")

    if fp is not None and tn is not None:
        print(f"\n  capacity gap  (teacher→FP18): "
              f"{(args.teacher_acc-acc(fp)):+.2f} pp" if args.teacher_acc else "")
        print(f"  quantization gap (FP18→ternary): {acc(tn)-acc(fp):+.2f} pp")

    print("\n---- Task 4: ternary + vanilla KD ----")
    for name, s in kds:
        if s is None:
            print(f"  [missing] {name}")
            continue
        delta_vs_t3 = (acc(s) - acc(tn)) if tn is not None else float("nan")
        verdict = "KD HELPS" if delta_vs_t3 > 0 else ("KD HURTS" if delta_vs_t3 < 0 else "no change")
        tstr = f"T={s.get('temperature','?')}, λ={s.get('kd_lambda','?')}, teacher={s.get('teacher_tag','?')}"
        print(f"  {tstr:45s} {acc(s):.2f}% ± {std(s):.2f}"
              f"   |  vs T3: {delta_vs_t3:+.2f} pp  ->  {verdict}")

    out = {
        "teacher_acc": args.teacher_acc,
        "fp32_student": acc(fp), "ternary_nokd": acc(tn),
        "ternary_kd": [{"name": n, "val_acc": acc(s),
                        "delta_vs_t3": (acc(s) - acc(tn)) if (s and tn) else None,
                        "T": (s or {}).get("temperature"), "lambda": (s or {}).get("kd_lambda"),
                        "teacher_tag": (s or {}).get("teacher_tag")}
                       for n, s in kds if s is not None],
    }
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    with open(args.out, "w") as f:
        json.dump(out, f, indent=2)
    print(f"\nSaved -> {args.out}")
    print("Reminder: the T3-vs-T4 delta is the project's pivotal result — report its sign honestly.")


if __name__ == "__main__":
    main()
