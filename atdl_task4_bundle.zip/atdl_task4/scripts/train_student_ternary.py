#!/usr/bin/env python3
"""
scripts/train_student_ternary.py  —  ternary ResNet18 QAT trainer.

TASK 3: `--kd-mode none`  -> ternary QAT baseline, no KD (B2).
TASK 4: `--kd-mode vanilla` -> ternary QAT + vanilla (Hinton) KD from a frozen
        ResNet34 teacher (B3):  L = (1-λ)·CE + λ·T²·KL.

(This file is the Task-4 superset of the Task-3 script; `--kd-mode none` behaves
exactly as before. Advanced KD modes — dkd/dist/feature/… — still raise; they
are Task 5.)

Guarantees: teacher frozen (eval, requires_grad=False), no gradient into the
teacher (C6/C7); ternary constraint active every step (C5); selection on the
validation split, test set never touched here (C9/C11).
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import sys
import time

import numpy as np
import torch
import torch.nn as nn

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

from src.data import get_train_val_loaders, CIFAR10_MEAN, CIFAR10_STD  # noqa: E402
from src.models.resnet_cifar import resnet18_cifar  # noqa: E402
from src.quant.ternary import (  # noqa: E402
    QuantConfig, convert_to_ternary, ternary_parameter_groups, count_ternary_layers,
)
from src.evaluation.verify_ternary import verify_model  # noqa: E402
from src.training.utils import (  # noqa: E402
    set_seed, get_device, make_warmup_cosine, train_one_epoch, evaluate,
    save_checkpoint, save_history, save_training_curves,
)
from src.kd.vanilla import load_teacher, train_one_epoch_kd, teacher_val_accuracy  # noqa: E402

try:
    from tqdm.auto import tqdm
except Exception:  # pragma: no cover
    def tqdm(x=None, *a, **k):
        return x

SUPPORTED_KD = {"none", "vanilla"}          # Task 5 will add dkd/dist/feature/...


def parse_args():
    p = argparse.ArgumentParser(description="Ternary ResNet18 QAT trainer (Task 3 / Task 4)")
    # data / optim
    p.add_argument("--data-root", default="./data")
    p.add_argument("--epochs", type=int, default=200)
    p.add_argument("--batch-size", type=int, default=128)
    p.add_argument("--lr", type=float, default=0.1)
    p.add_argument("--scale-lr-with-batch", action="store_true", default=True)
    p.add_argument("--momentum", type=float, default=0.9)
    p.add_argument("--weight-decay", type=float, default=1e-4)
    p.add_argument("--nesterov", action="store_true", default=True)
    p.add_argument("--warmup-epochs", type=int, default=5)
    p.add_argument("--label-smoothing", type=float, default=0.1)
    p.add_argument("--num-workers", type=int, default=4)
    p.add_argument("--seeds", type=int, nargs="+", default=[42, 43, 44])
    p.add_argument("--strict-determinism", action="store_true", default=False)
    # quantizer
    p.add_argument("--threshold", choices=["twn", "ttq"], default="twn")
    p.add_argument("--scale", choices=["derived", "learned"], default="derived")
    p.add_argument("--symmetric", dest="symmetric", action="store_true", default=True)
    p.add_argument("--asymmetric", dest="symmetric", action="store_false")
    p.add_argument("--scope", choices=["per_channel", "per_tensor"], default="per_channel")
    p.add_argument("--t", type=float, default=0.05)
    p.add_argument("--ste", choices=["clipped", "identity"], default="clipped")
    p.add_argument("--clip", type=float, default=1.0)
    p.add_argument("--keep-first-last-fp32", action="store_true", default=False)
    # warm start (from Task 2 FP32 student)
    p.add_argument("--warm-start", default="results/best_models/resnet18_fp32_best.pth")
    p.add_argument("--no-warm-start", dest="warm_start", action="store_const", const="")
    # KD (Task 4)
    p.add_argument("--kd-mode", default="none", help="none (T3) | vanilla (T4)")
    p.add_argument("--teacher", default="results/best_models/resnet34_cifar10_fp32_final.pth",
                   help="frozen ResNet34 teacher checkpoint (Task 1).")
    p.add_argument("--teacher-arch", default="resnet34")
    p.add_argument("--teacher-tag", default="ls01",
                   help="label for the teacher (e.g. ls01 or ls00) — used in filenames.")
    p.add_argument("--temperature", type=float, default=4.0)
    p.add_argument("--kd-lambda", type=float, default=0.9)
    # io
    p.add_argument("--tag", default=None, help="override the output name prefix.")
    p.add_argument("--ckpt-dir", default="experiments/checkpoints")
    p.add_argument("--hist-dir", default="experiments/histories")
    p.add_argument("--plot-dir", default="plots")
    p.add_argument("--best-dir", default="results/best_models")
    p.add_argument("--summary", default=None)
    p.add_argument("--smoke", action="store_true", default=False)
    return p.parse_args()


def build_ternary_student(cfg, warm_start, keep_fl_fp32, device):
    model = resnet18_cifar(num_classes=10)
    warmed = False
    if warm_start:
        if os.path.exists(warm_start):
            ck = torch.load(warm_start, map_location="cpu", weights_only=False)
            model.load_state_dict(ck["model_state_dict"])
            warmed = True
        else:
            print(f"[warn] warm-start checkpoint not found ({warm_start}); training from scratch.")
    convert_to_ternary(model, cfg, keep_first_last_fp32=keep_fl_fp32)
    return model.to(device), warmed


def run_prefix(args) -> str:
    if args.tag:
        return args.tag
    if args.kd_mode == "none":
        return "resnet18_ternary_noKD"
    return f"resnet18_ternary_vanillaKD_{args.teacher_tag}_T{args.temperature:g}_lam{args.kd_lambda:g}"


def train_one_seed(seed, args, cfg, device, teacher, prefix):
    set_seed(seed, strict=args.strict_determinism)
    eff_lr = args.lr * args.batch_size / 128.0 if args.scale_lr_with_batch else args.lr
    epochs = 1 if args.smoke else args.epochs

    train_loader, val_loader, tr_idx, va_idx = get_train_val_loaders(
        data_root=args.data_root, batch_size=args.batch_size,
        num_workers=args.num_workers, loader_seed=seed)

    model, warmed = build_ternary_student(cfg, args.warm_start, args.keep_first_last_fp32, device)
    nconv, nlin = count_ternary_layers(model)
    criterion = nn.CrossEntropyLoss(label_smoothing=args.label_smoothing)
    optimizer = torch.optim.SGD(ternary_parameter_groups(model, args.weight_decay),
                                lr=eff_lr, momentum=args.momentum, nesterov=args.nesterov)
    scheduler = make_warmup_cosine(optimizer, args.warmup_epochs, epochs)

    kd = args.kd_mode != "none"
    config = {
        "task": "T4_ternary_vanillaKD" if kd else "T3_ternary_baseline_noKD",
        "arch": "ResNet18-CIFAR-ternary", "seed": seed, "epochs": epochs,
        "batch_size": args.batch_size, "effective_lr": eff_lr, "weight_decay": args.weight_decay,
        "warmup_epochs": args.warmup_epochs, "label_smoothing": args.label_smoothing,
        "warm_started_from_fp32": warmed, "num_classes": 10,
        "normalization": {"mean": list(CIFAR10_MEAN), "std": list(CIFAR10_STD)},
        "ternary_conv_layers": nconv, "ternary_linear_layers": nlin,
        "kd_mode": args.kd_mode,
    }
    if kd:
        config.update({"teacher": args.teacher, "teacher_tag": args.teacher_tag,
                       "temperature": args.temperature, "kd_lambda": args.kd_lambda})
    quant_config = vars(cfg).copy()

    history = {"train_loss": [], "train_acc": [], "val_loss": [], "val_acc": [], "lr": [], "gap": []}
    if kd:
        history["ce_loss"] = []
        history["kl_loss"] = []
    best_val, best_epoch = 0.0, -1
    ckpt_path = os.path.join(args.ckpt_dir, f"{prefix}_seed{seed}.pth")

    tag = (f"KD(vanilla,{args.teacher_tag},T={args.temperature:g},λ={args.kd_lambda:g})"
           if kd else "no-KD")
    print(f"\n=== Seed {seed} | ternary ResNet18 | {tag} | {epochs} ep | eff_lr={eff_lr:.4f} "
          f"| quant={cfg.scope}/{cfg.threshold}/{'sym' if cfg.symmetric else 'asym'} "
          f"| warm_start={warmed} ===")
    t0 = time.time()
    for epoch in range(1, epochs + 1):
        cur_lr = optimizer.param_groups[0]["lr"]
        if kd:
            tr_loss, ce_l, kl_l, tr_acc = train_one_epoch_kd(
                model, teacher, train_loader, optimizer, device,
                args.temperature, args.kd_lambda, criterion,
                progress=lambda it: tqdm(it, desc=f"S{seed} Ep{epoch}/{epochs}", leave=False))
            history["ce_loss"].append(ce_l)
            history["kl_loss"].append(kl_l)
        else:
            tr_loss, tr_acc = train_one_epoch(
                model, train_loader, criterion, optimizer, device,
                progress=lambda it: tqdm(it, desc=f"S{seed} Ep{epoch}/{epochs}", leave=False))
        va_loss, va_acc = evaluate(model, val_loader, criterion, device)
        scheduler.step()
        gap = tr_acc - va_acc
        for k, v in [("train_loss", tr_loss), ("train_acc", tr_acc), ("val_loss", va_loss),
                     ("val_acc", va_acc), ("lr", cur_lr), ("gap", gap)]:
            history[k].append(v)
        if not (np.isfinite(tr_loss) and np.isfinite(va_loss)):
            raise RuntimeError(f"NaN/inf loss at epoch {epoch} — diverged (lower LR / check STE/T).")
        improved = va_acc > best_val
        if improved:
            best_val, best_epoch = va_acc, epoch
            save_checkpoint(ckpt_path, model, optimizer, scheduler, epoch, best_val, config,
                            extra={"quant_config": quant_config,
                                   "keep_first_last_fp32": args.keep_first_last_fp32})
        extra = f" | ce {ce_l:.3f} kl {kl_l:.3f}" if kd else ""
        print(f"S{seed} Ep{epoch:3d}/{epochs} | train {tr_loss:.4f}/{100*tr_acc:5.2f}% | "
              f"val {va_loss:.4f}/{100*va_acc:5.2f}% | gap {100*gap:5.2f}%{extra} | lr {cur_lr:.5f}"
              + ("  <-- best" if improved else ""))

    elapsed = time.time() - t0
    save_history(os.path.join(args.hist_dir, f"{prefix}_seed{seed}.json"),
                 history, {"best_val_acc": best_val, "best_epoch": best_epoch,
                           "config": config, "quant_config": quant_config, "elapsed_sec": elapsed})
    save_training_curves(history, os.path.join(args.plot_dir, f"{prefix}_seed{seed}"))

    best = resnet18_cifar(10).to(device)
    convert_to_ternary(best, cfg, keep_first_last_fp32=args.keep_first_last_fp32)
    best.load_state_dict(torch.load(ckpt_path, map_location=device, weights_only=False)["model_state_dict"])
    vinfo = verify_model(best, verbose=False)
    print(f"Seed {seed} done in {elapsed/60:.1f} min | best val {100*best_val:.2f}% @ ep {best_epoch} "
          f"| sparsity {100*vinfo['sparsity']:.1f}% | all_ternary={vinfo['all_ternary']}")
    return {"seed": seed, "best_val_acc": best_val, "best_epoch": best_epoch, "ckpt": ckpt_path,
            "final_train_acc": history["train_acc"][-1], "sparsity": vinfo["sparsity"],
            "all_ternary": vinfo["all_ternary"], "elapsed_sec": elapsed}


def main():
    args = parse_args()
    if args.kd_mode not in SUPPORTED_KD:
        raise NotImplementedError(
            f"kd-mode '{args.kd_mode}' is not implemented yet (Task 5). "
            f"Supported now: {sorted(SUPPORTED_KD)} (none=Task 3, vanilla=Task 4)."
        )
    cfg = QuantConfig(threshold=args.threshold, scale=args.scale, symmetric=args.symmetric,
                      scope=args.scope, t=args.t, ste=args.ste, clip=args.clip).validate()
    device = get_device()
    prefix = run_prefix(args)

    print("==== Ternary ResNet18 QAT trainer ====")
    print(f"Python {platform.python_version()} | torch {torch.__version__} | device {device}")
    if torch.cuda.is_available():
        print(f"GPU: {torch.cuda.get_device_name(0)}")
    print(f"kd_mode={args.kd_mode} | quant={vars(cfg)}")

    teacher = None
    if args.kd_mode == "vanilla":
        if not os.path.exists(args.teacher):
            raise FileNotFoundError(
                f"Teacher checkpoint not found: {args.teacher}\n"
                f"Point --teacher at your Task 1 ResNet34 checkpoint "
                f"(e.g. resnet34_cifar10_fp32_final.pth)."
            )
        teacher, tck = load_teacher(args.teacher, device, arch=args.teacher_arch)
        print(f"Teacher loaded (FROZEN, eval): {args.teacher} "
              f"[tag={args.teacher_tag}, reported best={tck.get('best_test_accuracy', tck.get('best_val_accuracy','?'))}]")

    results = [train_one_seed(s, args, cfg, device, teacher, prefix) for s in args.seeds]
    val_accs = np.array([r["best_val_acc"] for r in results])
    overall_best = max(results, key=lambda r: r["best_val_acc"])

    os.makedirs(args.best_dir, exist_ok=True)
    best_out = os.path.join(args.best_dir, f"{prefix}_best.pth")
    torch.save(torch.load(overall_best["ckpt"], map_location="cpu", weights_only=False), best_out)

    summary_path = args.summary or f"results/{prefix}_summary.json"
    summary = {
        "task": "T4_ternary_vanillaKD" if args.kd_mode != "none" else "T3_ternary_baseline_noKD",
        "kd_mode": args.kd_mode, "prefix": prefix, "seeds": args.seeds, "quant_config": vars(cfg),
        "val_acc_mean": float(val_accs.mean()), "val_acc_std": float(val_accs.std()),
        "val_acc_best": float(val_accs.max()), "best_seed": overall_best["seed"],
        "best_checkpoint": best_out, "sparsity_mean": float(np.mean([r["sparsity"] for r in results])),
        "all_ternary": all(r["all_ternary"] for r in results), "per_seed": results,
    }
    if args.kd_mode == "vanilla":
        summary.update({"teacher": args.teacher, "teacher_tag": args.teacher_tag,
                        "temperature": args.temperature, "kd_lambda": args.kd_lambda})
    os.makedirs(os.path.dirname(summary_path) or ".", exist_ok=True)
    with open(summary_path, "w") as f:
        json.dump(summary, f, indent=2)

    print("\n==== summary (validation) ====")
    print(f"[{prefix}] val acc: {100*val_accs.mean():.2f}% ± {100*val_accs.std():.2f} "
          f"(best {100*val_accs.max():.2f}%)")
    print(f"Best checkpoint -> {best_out}\nSummary -> {summary_path}")
    if args.kd_mode == "vanilla":
        print("Compare against Task 3 (no-KD) via scripts/compare_baselines.py to get the T3-vs-T4 delta.")


if __name__ == "__main__":
    main()
